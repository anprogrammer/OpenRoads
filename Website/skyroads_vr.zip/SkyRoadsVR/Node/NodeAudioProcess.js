﻿var rl = require('./RoadsLib');
GLOBAL.TSM = require('./JsLibs/tsm-node');
rl.Configurations.runNodeAudio();
//# sourceMappingURL=NodeAudioProcess.js.map
