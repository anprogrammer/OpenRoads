﻿var rl = require('./RoadsLib');
GLOBAL.TSM = require('./JsLibs/tsm-node');
rl.Configurations.runNode(process.argv[2]);
//# sourceMappingURL=NodeMain.js.map
