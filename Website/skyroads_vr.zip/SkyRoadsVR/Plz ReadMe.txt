﻿Thank you for downloading SkyRoads VR, a modern VR engine for the classic game SkyRoads http://www.bluemoon.ee/history/skyroads/
Try to drive to the end of a track and through the tunnel.  Don't fall, crash, or touch pink tiles!
http://www.openroadsgame.com/
https://github.com/anprogrammer/OpenRoads
CrazyNorman@gmail.com

Be sure to set your Rift to Extended Mode.  I'll add Direct Mode support once some Win8/AMD/OpenGL issues are worked out.  If the game appears on your monitor instead of your Rift, press F9 to change displays.  Be sure to have the Rift set as your primary display device or else you may encounter unpleasent judder.

Controls:
	You can use either an X-Box 360 controller or a keyboard.  Other game-pads may work, I haven't tested them.
	Keyboard:
		Arrow Keys, WASD -- Turn/Speed-up/Slow down
		Spacebar to Jump
		Escape to Exit/Go-Back
		'r' to reset Rift orientation
		F9 to change displays (restarts game)
	X-Box 360 Controller:
		Use any joystick, triggers, or d-pad to turn, slow-down, speed-up
		A to jump/enter a menu
		B to exit
		X to reset Rift orientation

Common Issues:
	1.  I'm way to close to the dashboard
		Be sure to reset your orientation using "X" on a gamepad or 'r' on your keyboard
	2.  I get a missing DLL error.
		Be sure to install the x86/32-bit version of the Visual C++ Redistributable Packages for Visual Studio 2013 from http://www.microsoft.com/en-us/download/details.aspx?id=40784
	3.  I have no sound
		Open the "Manage Audio Devices" screen (can be accessed via Start Menu or right-clicking the speaker icon in the System Tray), and verify that your headphones are set as the "Default Device".  If setting them as the "Default Device" does not resolve the issue please e-mail me with a screenshot of your audio devices at
		CrazyNorman@gmail.com.  I'm still trying to track down some audio issues.